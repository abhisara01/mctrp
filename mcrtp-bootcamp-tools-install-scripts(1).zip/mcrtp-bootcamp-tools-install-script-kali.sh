#!/usr/bin/env bash
# Microsoft Cloud Attack and Defense Bootcamp install script for Kali Linux
# version 0.1
# https://bootcamps.pwnedlabs.io/mcrtp-bootcamp

# Get sudo credentials so that we can do privileged installations
username=$(id -u -n 1000)
arch=$(uname -m)
sudo -v

# Preparation tasks 
install_dir=/opt/mcrtp_bootcamp_tools
sudo mkdir -p "$install_dir"
sudo chown $username:$username $install_dir
sudo apt update && sudo apt install unzip curl hashcat evil-winrm pipx docker.io docker-compose -y

# Install Powershell tools
git clone https://github.com/Gerenios/AADInternals $install_dir/AADInternals
git clone https://github.com/dafthack/GraphRunner $install_dir/GraphRunner
git clone https://github.com/f-bader/TokenTacticsV2 $install_dir/TokenTacticsV2
git clone https://github.com/dafthack/MFASweep $install_dir/MFASweep

# Install python tools
git clone https://github.com/yuyudhn/AzSubEnum $install_dir/AzSubEnum
git clone https://github.com/joswr1ght/basicblobfinder $install_dir/basicblobfinder
git clone https://github.com/gremwell/o365enum $install_dir/o365enum
git clone https://github.com/0xZDH/o365spray $install_dir/o365spray
git clone https://github.com/0xZDH/Omnispray $install_dir/Omnispray
git clone https://github.com/dievus/Oh365UserFinder $install_dir/Oh365UserFinder
sudo mkdir -p $install_dir/exfil_exchange_mail
sudo chown $username:$username $install_dir/exfil_exchange_mail
wget https://raw.githubusercontent.com/rootsecdev/Azure-Red-Team/master/Tokens/exfil_exchange_mail.py -O $install_dir/exfil_exchange_mail/exfil_exchange_mail.py

# Install pip and pipx tools
pipx ensurepath --global
pipx install azure-cli
pipx install graphspy
pipx install "git+https://github.com/dirkjanm/ROADtools" --include-deps
pip install requests colorama

# Configure Docker to run under User Context
sudo usermod -aG docker $username

file_name=""
case $arch in
    x86_64)
        file_name="azurehound-linux-amd64.zip"
        ;;
    arm64 | aarch64)
        file_name="azurehound-linux-arm64.zip"
        ;;
    *)
        echo "Unsupported architecture: $arch"
        exit 1
        ;;
esac

# AzureHound
wget https://github.com/BloodHoundAD/AzureHound/releases/download/v2.1.7/${file_name} -O azurehound.zip
unzip azurehound.zip
mkdir azure_hound
mv ./azurehound azure_hound/
rm azurehound.zip

# Install BloodHoundCE
mkdir -p $install_dir/BloodhoundCE
curl https://raw.githubusercontent.com/SpecterOps/BloodHound/main/examples/docker-compose/docker-compose.yml -o /opt/mcrtp_bootcamp_tools/BloodhoundCE/docker-compose.yml

# Post Installation Activities
# Clear the terminal
clear

# Define color variables
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Instructions
echo -e "${BLUE}Bloodhound CE docker-compose file has been downloaded to /opt/mcrtp_bootcamp_tools/BloodhoundCE${NC}"
echo -e "${YELLOW}To launch Bloodhound CE, navigate to${NC} ${GREEN}"/opt/mcrtp_bootcamp_tools/BloodhoundCE/"${NC} ${YELLOW}and run the following command:${NC} ${GREEN}docker-compose up${NC}"
echo -e "${YELLOW}Note the randomly generated password from the logs, as you'll need it for the first login.${NC}"
echo -e "${YELLOW}To retrieve the password, use the command:${NC} ${GREEN}docker logs bloodhoundce_bloodhound_1 2>&1 | grep \"Initial Password Set To:\"${NC}"
echo -e "${YELLOW}Access the GUI at:${NC} ${GREEN}http://localhost:8080/ui/login${NC}. ${YELLOW}Ensure no other applications (e.g., BurpSuite) are using this port.${NC}"
echo -e "${YELLOW}Login using the username:${NC} ${GREEN}admin${NC} ${YELLOW}and the randomly generated password from the logs.${NC}"
echo -e "${YELLOW}Reboot your machine, then run the following command to update your PATH:${NC} ${GREEN}pipx ensurepath${NC}. ${YELLOW}Logout and log back in for changes to take effect.${NC}"

#### Install and configure PowerShell

# Update the curl command with the version for your architecture

#powershell-7.3.12-linux-arm32.tar.gz
#powershell-7.3.12-linux-arm64.tar.gz
#powershell-7.3.12-linux-x64.tar.gz

# Download the powershell '.tar.gz' archive
# curl -L -o /tmp/powershell.tar.gz https://github.com/PowerShell/PowerShell/releases/download/v7.3.12/powershell-7.3.12-linux-arm64.tar.gz

# Create the target folder where powershell will be placed
# sudo mkdir -p /opt/microsoft/powershell/7

# Expand powershell to the target folder
# sudo tar zxf /tmp/powershell.tar.gz -C /opt/microsoft/powershell/7

# Set execute permissions
# sudo chmod +x /opt/microsoft/powershell/7/pwsh

# Create the symbolic link that points to pwsh
# sudo ln -s /opt/microsoft/powershell/7/pwsh /usr/bin/pwsh

# install pwsh azure tools
# Install-Module -Name AADInternals -Force -scope currentuser
# Install-Module Microsoft.Graph -Force -Scope CurrentUser
# Install-Module -Name Az -Force -Scope CurrentUser
# Install-Module -Name AzureAD -allowclobber -Force -scope currentuser
# Install-Module -Name AzureADPreview -allowclobber -Force  -Scope CurrentUser
# Install-Module -Name MSOnline -Force  -Scope CurrentUser
