# Microsoft Cloud Attack and Defense Bootcamp Install Script for Windows
# Version 0.1
# https://bootcamps.pwnedlabs.io/mcrtp-bootcamp

Write-Host "Warning: Nested virtualization on Apple M1/M2 chips is not possible." -ForegroundColor Orange

$response = Read-Host "Do you wish to continue? (Yes/No)"

if ($response -eq 'Yes') {
    Write-Host "User chose to continue." -ForegroundColor Green
} else {
    Write-Host "Operation aborted by the user." -ForegroundColor Yellow
    exit
}

# Function to check if running as admin
function Test-Admin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
    Write-Error "This script must be run as an administrator."
    exit 1
}

# Prep folder
$toolFolder = "C:\mcrtp_bootcamp_tools"
New-Item -ItemType Directory -Force -Path $toolFolder
cd $toolFolder

Add-MpPreference -ExclusionPath $toolFolder

# Install Git
Write-Host "Downloading Git Installer..."
$gitInstaller = "$env:TEMP\Git-Installer.exe"
Invoke-WebRequest -Uri "https://github.com/git-for-windows/git/releases/download/v2.37.1.windows.1/Git-2.37.1-64-bit.exe" -OutFile $gitInstaller

Write-Host "Installing Git..."
Start-Process -FilePath $gitInstaller -ArgumentList "/VERYSILENT /NORESTART" -Wait -NoNewWindow
Remove-Item -Path $gitInstaller

# Install Python and add it to the system path
Write-Host "Downloading and installing Python..."
$pythonInstaller = "$env:TEMP\python-installer.exe"
Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.10.0/python-3.10.0-amd64.exe" -OutFile $pythonInstaller
Start-Process -FilePath $pythonInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 TargetDir=C:\Python310" -Wait -NoNewWindow
Remove-Item -Path $pythonInstaller

# Install PowerShell tools
C:\"Program Files"\Git\bin\git.exe clone https://github.com/Gerenios/AADInternals $toolFolder\AADInternals
C:\"Program Files"\Git\bin\git.exe clone https://github.com/dafthack/GraphRunner $toolFolder\GraphRunner
C:\"Program Files"\Git\bin\git.exe clone https://github.com/f-bader/TokenTacticsV2 $toolFolder\TokenTacticsV2
C:\"Program Files"\Git\bin\git.exe clone https://github.com/dafthack/MFASweep $toolFolder\MFASweep

# Install python tools
C:\"Program Files"\Git\bin\git.exe clone https://github.com/yuyudhn/AzSubEnum $toolFolder\AzSubEnum
C:\"Program Files"\Git\bin\git.exe clone https://github.com/joswr1ght/basicblobfinder $toolFolder\basicblobfinder
C:\"Program Files"\Git\bin\git.exe clone https://github.com/gremwell/o365enum $toolFolder\o365enum
C:\"Program Files"\Git\bin\git.exe clone https://github.com/0xZDH/o365spray $toolFolder\o365spray
C:\"Program Files"\Git\bin\git.exe clone https://github.com/0xZDH/Omnispray $toolFolder\Omnispray
C:\"Program Files"\Git\bin\git.exe clone https://github.com/dievus/Oh365UserFinder $toolFolder\Oh365UserFinder
New-Item -Force -ItemType Directory -Path "$toolFolder\exfil_exchange_mail"
Invoke-WebRequest "https://raw.githubusercontent.com/rootsecdev/Azure-Red-Team/master/Tokens/exfil_exchange_mail.py" -OutFile "$toolFolder\exfil_exchange_mail\exfil_exchange_mail.py"
# C:\"Program Files"\Git\bin\git.exe clone https://github.com/dirkjanm/ROADtools $toolFolder\ROADtools
# Start-Process -FilePath "C:\Python310\python.exe" -ArgumentList "$toolFolder\ROADtools\setup.py install" -Wait -NoNewWindow

# Set Git Path
$gitPath = "C:\Program Files\Git\bin"
$env:Path = "$gitPath;$env:Path"

# Install pip and pipx tools
Start-Process -FilePath "C:\Python310\python.exe" -ArgumentList "-m pip install requests colorama" -Wait -NoNewWindow
Start-Process -FilePath "C:\Python310\python.exe" -ArgumentList "-m pip install --user pipx" -Wait -NoNewWindow
Start-Process -FilePath "C:\Python310\python.exe" -ArgumentList "-m pipx install azure-cli graphspy" -Wait -NoNewWindow
Start-Process -FilePath "C:\Python310\python.exe" -ArgumentList "-m pipx install git+https://github.com/dirkjanm/ROADtools" -Wait -NoNewWindow
Start-Process -FilePath "C:\Python310\python.exe" -ArgumentList "-m pipx ensurepath" -Wait -NoNewWindow

# Determine system architecture and set download URLs
$architecture = (Get-WmiObject -Class Win32_Processor).AddressWidth
switch ($architecture) {
    64 { 
        $azureHoundFile = "azurehound-windows-amd64.zip"
    }
    32 { 
        $azureHoundFile = "Not available" # Update if IA-32 is available in the future
    }
    default {
        $azureHoundFile = "azurehound-windows-arm64.zip"
    }
}

# Download and extract AzureHound
if ($azureHoundFile -ne "Not available") {
    $azureHoundUrl = "https://github.com/BloodHoundAD/AzureHound/releases/download/rolling/$azureHoundFile"
    Invoke-WebRequest -Uri $azureHoundUrl -OutFile "$toolFolder\AzureHound.zip"
    Start-Process -FilePath "C:\Program Files\7-Zip\7z.exe" -ArgumentList "x `"$toolFolder\AzureHound.zip`" -o`"$toolFolder\AzureHound`" -y" -NoNewWindow -Wait
    Remove-Item -Path "$toolFolder\AzureHound.zip"
}

Write-Host "BloodHound and AzureHound have been downloaded and extracted successfully."

# Download and install 7-Zip
Invoke-WebRequest -Uri "https://www.7-zip.org/a/7z1900-x64.exe" -OutFile "$toolFolder\7z1900-x64.exe"
Start-Process -FilePath "$toolFolder\7z1900-x64.exe" -ArgumentList "/S" -NoNewWindow -Wait
Remove-Item -Path "$toolFolder\7z1900-x64.exe"

# BloodHoundCE Installation
## Install Docker Desktop and Docker Compose
$installationDirectory = "C:\mcrtp_bootcamp_tools\BloodHoundCE"
$dockerDesktopInstallerUrl = "https://desktop.docker.com/win/stable/Docker%20Desktop%20Installer.exe"
$installerPath = Join-Path -Path $installationDirectory -ChildPath "DockerDesktopInstaller.exe"

if (-not (Test-Path -Path $installationDirectory)) {
    Write-Host "Creating installation directory: $installationDirectory"
    New-Item -Path $installationDirectory -ItemType Directory | Out-Null
}

function Download-File {
    param (
        [string]$url,
        [string]$outputPath
    )
    
    try {
        Write-Host "Downloading $url to $outputPath..."
        Invoke-WebRequest -Uri $url -OutFile $outputPath
        Write-Host "Download completed."
    }
    catch {
        Write-Error "Failed to download $url. $_"
        exit 1
    }
}

function Install-DockerDesktop {
    param (
        [string]$installerPath
    )
    
    Write-Host "Starting Docker Desktop installation silently..."
    try {
        Start-Process $installerPath "install --quiet" -Wait -NoNewWindow
        Write-Host "Silent installation completed. Docker Desktop should now be starting."
    }
    catch {
        Write-Error "Failed to install Docker Desktop silently. $_"
        exit 1
    }

    # Wait for Docker Desktop to be installed and started
    Write-Host "Waiting for Docker Desktop to initialize..."
    Start-Sleep -Seconds 60
}

Download-File -url $dockerDesktopInstallerUrl -outputPath $installerPath

Install-DockerDesktop -installerPath $installerPath

Write-Host "Cleaning up installer files..."
if (Test-Path -Path $installerPath) {
    Remove-Item -Path $installerPath -Force
    Write-Host "Installer file removed."
} else {
    Write-Host "Installer file not found. Nothing to clean up."
}

## Use the pre-configured Docker Compose setup for BloodHoundCE
$dockerComposeUrl = "https://raw.githubusercontent.com/SpecterOps/BloodHound/main/examples/docker-compose/docker-compose.yml"
$dockerComposePath = Join-Path -Path $installationDirectory -ChildPath "docker-compose.yml"
Download-File -url $dockerComposeUrl -outputPath $dockerComposePath

# Write-Host "Initiating BloodHoundCE..."
Write-Host "Bloodhound CE docker-compose file has been downloaded to C:\mcrtp_bootcamp_tools\BloodhoundCE"
Write-Host "To launch Bloodhound CE, navigate to C:\mcrtp_bootcamp_tools\BloodhoundCE\ and run the following command: docker-compose up"
Write-Host "Note the randomly generated password from the logs, as you'll need it for the first login."
Write-Host "To retrieve the password, use the command: docker logs bloodhoundce_bloodhound_1 2>&1 | Select-String 'Initial Password Set To:'"
Write-Host "Access the GUI at: http://localhost:8080/ui/login. Ensure no other applications (e.g., BurpSuite) are using this port."
Write-Host "Login using the username: admin and the randomly generated password from the logs."
Write-Host "Docker Desktop installation completed. Please restart your computer and launch Docker Desktop to complete the initial configuration settings. When finished, start and then run BloodhoundCE."
Write-Host "Installation completed successfully. Please verify all tools are configured correctly before use."

# install pwsh azure tools
# Install-Module -Name AADInternals -Force -scope currentuser
# Install-Module Microsoft.Graph -Force -Scope CurrentUser
# Install-Module -Name Az -Force -Scope CurrentUser
# Install-Module -Name AzureAD -allowclobber -Force -scope currentuser
# Install-Module -Name AzureADPreview -allowclobber -Force  -Scope CurrentUser
# Install-Module -Name MSOnline -Force  -Scope CurrentUser

